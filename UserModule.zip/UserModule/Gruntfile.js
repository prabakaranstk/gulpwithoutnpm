module.exports = function(grunt) {

  grunt.initConfig({

   pkg: grunt.file.readJSON('package.json'),
   
    jshint: {
      all: ['public/js/*.js'] 
    },

	
	
    uglify: {
      build: {
        files: {
          'UserModule/dist/js/app.min.js': ['public/js/*.js']
        }
      }
    },

    less: {
      build: {
        files: {
          'UserModule/dist/css/style.css': 'public/css/*.css'
		  
        }
      }
    },
	
    watch: {
      css: {
        files: ['public/css/*.css'],
        tasks: ['less']
      },
      js: {
        files: ['public/js/*.js'],
        tasks: ['jshint', 'uglify']
      },
	  htmlmin:
	  {
        files: ['public/views/*.html'],
        tasks: ['htmlmin']
      }
    },


    nodemon: {
      dev: {
        script: 'server.js'
      }
    },

	
    concurrent: {
      options: {
        logConcurrentOutput: true
      },
      tasks: ['nodemon', 'watch','compress','htmlmin','ejs','copy']
    }
	,
	 compress: {
      main: {
        options: {
          archive: './UserModule.zip'
        },
        files: [
          
          {src: Object.keys(require('./package.json').dependencies).map(function(module){
            return "UserModule/**"
          }),dest:'.'},
        ]
      }
    },
	 htmlmin: {                                     
    dist: {
        options: {
          removeComments: true,
          collapseWhitespace: true,
          removeEmptyAttributes: true,
          removeCommentsFromCDATA: true,
          removeRedundantAttributes: true,
          collapseBooleanAttributes: true,
        },
        files: {
          'UserModule/views/main-min.html': './public/views/main.html'
        }
      },
      dev: {
        files: {
          'UserModule/views/main-min.html': './public/views/main.html'
        }
      },  
	  multiple: 
	  {                                  
		files: [{                                
        expand: true,
        cwd: 'public/views/',                             
        src: '**/*.html',                       
        dest: 'UserModule/views'                            
			}]
	  }
	
	
  },
  
   ejs: {
    all: {
	  cwd: 'public/views/',
      src: '**/*.ejs', 
      dest: 'UserModule/views',
      expand: true,
      ext: '.ejs',
    },
  }
  ,
  
  copy: {
  dist: {
    files: [
  
             {
			 expand: true, 
			 cwd: 'public/img',
			 src: ['**'], 
			 dest: 'UserModule/src/img'
			 },
			 {
			 expand: true, 
			 cwd: 'public/lib',
			 src: ['**'], 
			 dest: 'UserModule/src/lib'
			 }
			 ,
			 {
			 expand: true, 
			 cwd: 'public/js',
			 src: ['**'], 
			 dest: 'UserModule/src/js'
			 }
			 ,
			 { src:"package.json", dest:"UserModule/package.json" },
			 { src:"Gruntfile.js", dest:"UserModule/Gruntfile.js" },
			 { src:"server.js", dest:"UserModule/server.js" }
			 
			 
		]
		}
		}
  
  
	

		  
	
  });


  
  
  grunt.loadNpmTasks('grunt-contrib-jshint');
  grunt.loadNpmTasks('grunt-contrib-uglify');
  grunt.loadNpmTasks('grunt-contrib-less');
  grunt.loadNpmTasks('grunt-contrib-cssmin');
  grunt.loadNpmTasks('grunt-contrib-watch');
  grunt.loadNpmTasks('grunt-nodemon');
  grunt.loadNpmTasks('grunt-concurrent');
  grunt.loadNpmTasks('grunt-contrib-compress');
  grunt.loadNpmTasks('grunt-contrib-copy');
  grunt.loadNpmTasks('grunt-contrib-htmlmin');
  grunt.loadNpmTasks('grunt-ejs');
 
  grunt.registerTask('default', ['less', 'jshint','uglify','concurrent','compress','htmlmin','ejs','copy']);

};