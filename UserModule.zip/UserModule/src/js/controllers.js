var UserModule = angular.module('userApp', ['userServices']);


UserModule.controller('UserController', ['$scope','User','$http','$templateCache','$window',
function($scope,User,$http,$templateCache,$window) 
{

$scope.users = User.query();

$scope.edit = function(id,form) 
{
 	
	
		var method = 'PUT';
		var inserturl = 'http://localhost:3000/user/updateuser/'+id;
		$scope.codeStatus = "";

	  var formData = {
				'id': id,
	     'firstname': document.getElementById("fn_"+id).value,
	      'lastname': document.getElementById("ln_"+id).value,
			 'email': document.getElementById("em_"+id).value,
		  'mobileno': document.getElementById("mn_"+id).value
	    };
	 
	    this.firstname = '';
	    this.lastname = '';
	    this.email = '';
		this.mobileno='';
		
	    var userdata = 'userdata='+JSON.stringify(formData);
		
	  
	 	    $http({ 
				method	: method,
	            url		: inserturl,
	            data	: userdata ,
	            headers	: {'Content-Type': 'application/x-www-form-urlencoded'},
	            cache	: $templateCache
	        }).
	        success(function(response) 
			{
	                $scope.codeStatus = response.data;
	        }).
	        error(function(response) 
			{
					log.error(response); 
	                $scope.codeStatus = response || "Request failed";
	        });  
	
			alert("record is updated");	
	        return false;
	 
 
 };
 
 
 $scope.deleteUser = function(id) {
		var method = 'PUT';
		var deleteurl = 'http://localhost:3000/user/deleteuser.html';
		$scope.codeStatus = "";
		
		
	    var userid = 'id='+id;
		
	  
	 	    $http({ 
				method	: method,
	            url		: deleteurl,
	            data	: userid ,
	            headers	: {'Content-Type': 'application/x-www-form-urlencoded'},
	            cache	: $templateCache
	        }).
	        success(function(response) 
			{
				
	                $scope.codeStatus = response.data;
				
	        }).
	        error(function(response) 
			{
					log.error(response); 
	                $scope.codeStatus = response || "Request failed";
					
	        });  


			alert("record is deleted");	
			
			$window.location.href = 'http://localhost:3000/views/main.html';
	        return false;

 };
    
}]);


function UserListCtrl($scope, $http, $templateCache,$window) {

		var method = 'POST';
		var inserturl = 'http://localhost:3000/user/insertuser.html';
		$scope.codeStatus = "";
	$scope.save = function() 
	{
	   
	  var formData = 
	  {
			'id'		: this.userid,
			'firstname'	: this.firstname,
			'lastname'	: this.lastname,
			'email' 	: this.email,
			'mobileno'	: this.mobileno
	  };
	 
	    this.firstname	= '';
	    this.lastname	= '';
	    this.email		= '';
		this.mobileno	='';
		
	    var userdata = 'userdata='+JSON.stringify(formData);
		
	  
	 	    $http({ 
            method: method,
	            url: inserturl,
	            data:  userdata ,
	            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
	            cache: $templateCache
	        }).
	        success(function(response) 
			{
	                $scope.codeStatus = response.data;
					
	        }).
	        error(function(response) 
			{
					log.error(response); 
	                $scope.codeStatus = response || "Request failed";
				
	        });    
			
			 alert("recoed is saved");
			
			$window.location.href = 'http://localhost:3000/views/main.html';
	        return false;	  
   }; 

}