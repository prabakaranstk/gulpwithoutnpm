Code for the blog post: https://golb.hplar.ch/p/JWT-Authentication-with-Ionic-2-and-Spring-Boot
