var express = require('express');
var bodyParser = require('body-parser');
var app = express();
var blobStream=require("blob-stream");

var flash = require('connect-flash')
  , express = require('express')
  , passport = require('passport')
  , util = require('util')
  , LocalStrategy = require('passport-local').Strategy;

  
app.configure(function() {
  app.set('views', __dirname + '/public/views/');
  app.use("/static", express.static(__dirname + "/public/views"));
  app.set('view engine', 'ejs');
  app.use(express.logger());
  app.use(express.cookieParser());
  app.use(express.bodyParser());
  app.use(express.methodOverride());
  app.use(express.session({ secret: '498f99f3bbee4ae3a075eada02488464' , cookie: { maxAge:  3600000 }}));
  app.use(flash());
  app.use(passport.initialize());
  app.use(passport.session());
  app.use(app.router);
 
});
  
var mongoose = require('mongoose/');
mongoose.connect('mongodb://localhost/UserLogin');



//var router = express.Router();
//var index = require('./routes/index').router;
//app.use('/',index);



var Schema = mongoose.Schema;
var UserDetail = new Schema({
		fisrtname:String,
		lastname:String,
      username: String,
      password: String
    }, {
      collection: 'userInfo'
    });
var UserDetails = mongoose.model('userInfo', UserDetail);


var jsonParser = bodyParser.json();
var urlencodedParser = bodyParser.urlencoded({ extended: false });

passport.serializeUser(function(user, done) {
  done(null, user);
});

passport.deserializeUser(function(user, done) {
  done(null, user);
});

app.post('/register', function(req, res) 
{ 
 var UserData=UserDetails({fisrtname: req.body.first_name,lastname:req.body.last_name,username:req.body.username,password:req.body.password});
  
  UserData.save(function(err) 
  {
	if (err) throw err;
  });
	res.redirect('/');
});

passport.use(new LocalStrategy(function(username, password, done) {
  process.nextTick(function() {
    UserDetails.findOne({
      'username': username, 
    }, function(err, user) {
      if (err) {
        return done(err);
      }
 
      if (!user) {
        return done(null, false);
      }
 
      if (user.password != password) {
        return done(null, false);
      }
 
      return done(null, user);
    });
  });
}));


var MongoClient = require('mongodb').MongoClient
    , format = require('util').format;

MongoClient.connect('mongodb://127.0.0.1:27017/Users', function(err, db) 
{

if(err) throw err;
var collection = db.collection('Users');
 
 
 app.use(function (req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header('Access-Control-Allow-Methods', 'GET,PUT,POST,DELETE');
  res.header("Access-Control-Allow-Headers", "X-Requested-With, Content-Type");
  next();
});
 
 
 
 
app.get('/user/getuser.html',ensureAuthenticated,jsonParser, function(req, res)
{


 collection.find(function(err, cursor) 
 {
      cursor.toArray(function(err, usersdata) {
	 
        res.send(usersdata);
      });

	});
	

});


app.post('/user/insertuser.html', ensureAuthenticated,urlencodedParser,function (req, res){	 
	 
		 console.log(req.body);
	     console.log(req.body.userdata);
		 var userData = JSON.parse(req.body.userdata);
		  db.collection('Users').insert(userData, function(err, records) 
		  {
				if (err) throw err;
				
			});	
				
});

app.put('/user/updateuser/:id', ensureAuthenticated,urlencodedParser,function (req, res){
	
		var userData = JSON.parse(req.body.userdata);	 
		var id = req.params.id;
		
				
		 db.collection('Users').update({id: id}, {$set: userData}, userData, function(err) 
		 {
		 
			if (err) log.error(err.message);
			else console.log('successfully updated');
		});
					
	
});


app.put('/user/deleteuser.html',ensureAuthenticated, urlencodedParser,function (req, res){
	 			 
		var id = {
        id: req.body.id
		};

		var collection = db.collection("Users");
		collection.remove(id, function(err, records){
        if(err){
           log.error(err.message);                
        }
        else{                
            console.log("record is Removed");
        }
    });
		
});

app.get('/user/getuserbyid/:id',ensureAuthenticated,jsonParser, function(req, res)
{

	var id = req.params.id
	console.log(id);
	
	collection.findOne({id:id},function(err, doc) 
	{
      if (err) return next(err)
		res.send(doc);
	});
	

});




});


app.get('/', function(req, res){
  //res.render('login', { user: req.user, message: req.flash('error') });
   res.sendfile('./public/views/login.html');
});

app.post('/login', 
  passport.authenticate('local', { failureRedirect: '/', failureFlash: true }),
  function(req, res) 
  {
	
		req.session.userName = req.body.username;
		
		res.redirect('/views/main.html');
   
  });

  
app.get('/logout', function(req, res){
  req.logout();
  res.redirect('/');
});

app.get('/views/signup.html', function(req, res) {
    res.sendfile('./public/views/signup.html');
});

app.get('/views/main.html',ensureAuthenticated, function(req, res) {
    res.sendfile('./public/views/index.html');
});

 app.get('/views/controllers.js',ensureAuthenticated, function(req, res) {
    res.sendfile('./public/js/controllers.js');
});

app.get('/views/bg7.jpeg',function(req, res) {
    res.sendfile('./public/img/bg7.jpg');
});

app.get('/views/services.js',ensureAuthenticated, function(req, res) {
    res.sendfile('./public/js/services.js');
});

app.get('/views/bootstrap-table.js',ensureAuthenticated, function(req, res) {
    res.sendfile('./public/lib/bootstrap-table.js');
});

app.get('/views/bootstrap-table.css',ensureAuthenticated, function(req, res) {
    res.sendfile('./public/lib/bootstrap-table.css');
});
app.get('/views/main.css',ensureAuthenticated, function(req, res) {
    res.sendfile('./public/css/main.css');
});

 app.get('/user/useredit/:id',ensureAuthenticated, function(req, res) {
	var id = req.params.id; 
	res.send("id"+id);
    res.sendfile('./user/getuserbyid/'+id);
}); 

app.post('/getSession', function(req, res)
{
	res.send(req.session.userName);
});

app.get('/getPdf', function(req, res)
{
	var PDFDocument = require('pdfkit');
	var fs = require('fs');
	var doc = new PDFDocument();
   
    doc.info.Title = 'User Pdf';
    doc.info.Author = 'admin';
    doc.info.Subject = 'UserReportDetail';
	
	  request({
        url: 'http://localhost:3000/user/getuser.html',
        encoding: null
    }, function(err, response, body) {
        if (err) throw err;      
        doc.text(body);                       
       
        return;
    });

	
	
	
	
	doc.pipe(res);
    doc.end();
	
});	
	
app.listen(3000);


function ensureAuthenticated(req, res, next) {
  if (req.isAuthenticated()) { return next(); }
  res.redirect('/');
}